import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto1_18401194/services/firebase_service.dart';
import 'package:dam_u4_proyecto1_18401194/consultas.dart';
class ConsultaDepto extends StatefulWidget {
  const ConsultaDepto({Key? key}) : super(key: key);

  @override
  State<ConsultaDepto> createState() => _ConsultaDeptoState();
}

class _ConsultaDeptoState extends State<ConsultaDepto> {
  TextEditingController verDeptoController=TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    verDeptoController=arguments['deptover'];
    return Scaffold(
      appBar: AppBar(title: const Text("Vehiculos por departamento"),backgroundColor: Colors.deepPurpleAccent,),
      body: FutureBuilder(
        future: getVehiculoDepto(verDeptoController.text),
        builder: ((context,snapshot){
          if(snapshot.hasData){
            return ListView.builder(itemCount: snapshot.data?.length,itemBuilder: (context,index){
              return InkWell(onTap: (){},
                child: ListTile(
                  title: Text(snapshot.data?[index]['placa']),
                  subtitle: Text(snapshot.data?[index]['trabajador']),
                  trailing: Text(snapshot.data?[index]['tipo']),
                ),
              );
            },
            );
          }else{
            return const Center(child: Text("no se encuentra el departamento"),);
          }
        }
        ),
      ),

    );
  }
}
