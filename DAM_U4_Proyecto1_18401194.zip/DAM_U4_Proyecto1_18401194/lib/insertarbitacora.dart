import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto1_18401194/services/firebase_service.dart';
class Insertarbitacora extends StatefulWidget {
  const Insertarbitacora({Key? key}) : super(key: key);

  @override
  State<Insertarbitacora> createState() => _InsertarbitacoraState();
}

class _InsertarbitacoraState extends State<Insertarbitacora> {
  TextEditingController placaController = TextEditingController(text: "");
  TextEditingController eventoController = TextEditingController(text: "");
  TextEditingController recursosController = TextEditingController(text: "");
  TextEditingController verificoController = TextEditingController(text: "");
  TextEditingController fechaController = TextEditingController(text: "");
  TextEditingController fechaverificacionController = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Agregar Bitacora"),),
      body: Padding(padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          TextField(
            controller: placaController,
            decoration: const InputDecoration(hintText: 'Placa'),
          ),
          TextField(
            controller: eventoController, decoration: const InputDecoration(hintText: 'evento'),
          ),
          TextField(
            controller: recursosController, decoration: const InputDecoration(hintText: 'recursos'),
          ),
          TextField(
            controller: verificoController, decoration: const InputDecoration(hintText: 'verifico'),
          ),
          TextField(
            controller: fechaController, decoration: const InputDecoration(hintText: 'año-mm-dd'),
          ),
          TextField(
            controller: fechaverificacionController, decoration: const InputDecoration(hintText: 'año-mm-dd'),
          ),
          ElevatedButton(onPressed: ()async{
            await addBitacora(placaController.text, eventoController.text, recursosController.text,
                verificoController.text, Timestamp.fromDate(DateTime.parse(fechaController.text)), Timestamp.fromDate(DateTime.parse(fechaverificacionController.text))).
            then((_) {Navigator.pop(context);});
          }, child: const Text("Guardar"))
        ],
      ),
      ),
    );
  }
}

// TODO Implement this library.