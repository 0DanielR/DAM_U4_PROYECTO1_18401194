import 'package:flutter/material.dart';


class Consultas extends StatefulWidget {
  const Consultas({Key? key}) : super(key: key);

  @override
  State<Consultas> createState() => _ConsultasState();
}

class _ConsultasState extends State<Consultas> {
  TextEditingController deptoController = TextEditingController(text: "");
  TextEditingController placController = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Consultas"),backgroundColor: Colors.blueGrey,),
      body: Padding(padding: const EdgeInsets.all(30),
      child: Column(
        children: [
          SizedBox(height: 10,),
          Text("Consultas de Departamento"),
          TextField(controller: deptoController,decoration: const InputDecoration(hintText: 'depto'),),
          SizedBox(height: 10,),
          ElevatedButton(onPressed: (){
            Navigator.pushNamed(context, '/conDepto',arguments: {
              "deptover":deptoController
            });
          }, child: const Text("Ver")),
          SizedBox(height: 20,),
          Text("Consultas por Placas"),
          TextField(controller: placController,decoration: const InputDecoration(hintText: 'placa'),),
          SizedBox(height: 10,),
          ElevatedButton(onPressed: (){
            Navigator.pushNamed(context, '/conPlaca',arguments: {
              "placaver":placController
            });
          }, child: const Text("Ver")),
        ],
      ),
      )

    );
  }
}

