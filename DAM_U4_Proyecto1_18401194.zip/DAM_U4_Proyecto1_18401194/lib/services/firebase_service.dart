import 'package:cloud_firestore/cloud_firestore.dart';

FirebaseFirestore db=FirebaseFirestore.instance;

Future<List> getVehiculoDepto (String deptox) async{
  List vehiculoPlaca=[];

  QuerySnapshot queryVehiculo = await db.collection('vehiculo').where('depto',isEqualTo: deptox).get();

  queryVehiculo.docs.forEach((documento) {
    final Map<String,dynamic> data=documento.data() as Map<String,dynamic>;

    final vehiculo ={
      "uid":documento.id,
      "combustible":data['combustible'],
      "depto":data['depto'],
      "numeroserie":data['numeroserie'],
      "placa":data['placa'],
      "resguardadopor":data['resguardadopor'],
      "tanque":data['tanque'],
      "tipo":data['tipo'],
      "trabajador":data['trabajador']
    };
    vehiculoPlaca.add(vehiculo);

  });
  return vehiculoPlaca;
}

Future<List> getBitacoraPlaca(String placax) async{
  List bitacoraPlaca=[];
  QuerySnapshot queryBitacora = await db.collection('bitacora').where('placa',isEqualTo: placax).get();
  queryBitacora.docs.forEach((documento) {
    final Map<String,dynamic> data= documento.data() as Map<String,dynamic>;
    final bitacora ={
      "uid":documento.id,
      "placa":data['placa'],
      "fecha":data['fecha'],
      "evento":data['evento'],
      "recursos":data['recursos'],
      "verifico":data['verifico'],
      "fechaverificacion":data['fechaverificacion']
    };
      bitacoraPlaca.add(bitacora);

  });
  return bitacoraPlaca;
}

Future<List> getBitacora() async{
  List bitacoraPlaca=[];
  CollectionReference collectionReferenceBitacora = db.collection('bitacora');
  QuerySnapshot queryBitacora = await collectionReferenceBitacora.get();
  queryBitacora.docs.forEach((documento) {
    final Map<String,dynamic> data= documento.data() as Map<String,dynamic>;
    final bitacora ={
      "uid":documento.id,
      "placa":data['placa'],
      "fecha":data['fecha'],
      "evento":data['evento'],
      "recursos":data['recursos'],
      "verifico":data['verifico'],
      "fechaverificacion":data['fechaverificacion']
    };
      bitacoraPlaca.add(bitacora);
  });
  return bitacoraPlaca;
}

Future<List> getCoches() async{
  List coches=[];
  CollectionReference collectionReferenceCoche = db.collection('vehiculo');
  QuerySnapshot queryCoche = await collectionReferenceCoche.get();
  queryCoche.docs.forEach((documento) {
    final Map<String,dynamic> data = documento.data() as Map<String, dynamic>;
    final vehiculo ={
      "uid":documento.id,
      "combustible":data['combustible'],
      "depto":data['depto'],
      "numeroserie":data['numeroserie'],
      "placa":data['placa'],
      "resguardadopor":data['resguardadopor'],
      "tanque":data['tanque'],
      "tipo":data['tipo'],
      "trabajador":data['trabajador']
    };
    coches.add(vehiculo);
  });
  return coches;
}

Future<void> addCoches(String placa,String combustible, String depto, String numeroserie,
    String resguardadopor, num tanque, String tipo, String trabajador )async{
  await db.collection("vehiculo").add({
    "placa":placa,
    "combustible":combustible,
    "depto":depto,
    "numeroserie":numeroserie,
    "resguardadopor":resguardadopor,
    "tanque":tanque,
    "tipo":tipo,
    "trabajador":trabajador
  });
}

Future<void> addBitacora(String placa,String evento, String recursos, String verifico, Timestamp fechaverificacion, Timestamp fecha)async{
  await db.collection('bitacora').add({
    "placa":placa,
    "evento":evento,
    "recursos":recursos,
    "verifico":verifico,
    "fecha":fecha,
    "fechaverificacion":fechaverificacion
  });
}
//int.parse(tanqueController.text), tipoController.text, trabajadorController.text
Future<void> updateCoches(String uid, String newplaca, String newcombustible, String newdepto, String newnumeroserie, String newresguardado,
    int newtanque, String newtipo, String newtrabajador)async{
  await db.collection("vehiculo").doc(uid).set({
    "placa":newplaca,
    "combustible":newcombustible,
    "depto":newdepto,
    "numeroserie":newnumeroserie,
    "resguardadopor":newresguardado,
    "tanque":newtanque,
    "tipo": newtipo,
    "trabajador":newtrabajador
  });
}

Future<void> updateBitacoras(String uid, String newverifico, Timestamp newfechaverificacion,Timestamp newfecha, String newevento,
    String newplaca, String newrecursos) async{
  await db.collection("bitacora").doc(uid).set({
    "verifico":newverifico,
    "fechaverificacion":newfechaverificacion,
    "fecha":newfecha,
    "evento":newevento,
    "placa":newplaca,
    "recursos":newrecursos
  });
}

Future<void> deleteCoches(String uid)async{
  await db.collection("vehiculo").doc(uid).delete();
}