import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto1_18401194/services/firebase_service.dart';

class EditarCoche extends StatefulWidget {
  const EditarCoche({Key? key}) : super(key: key);

  @override
  State<EditarCoche> createState() => _EditarCocheState();
}

class _EditarCocheState extends State<EditarCoche> {
  TextEditingController placaController = TextEditingController(text: "");
  TextEditingController combustibleController = TextEditingController(text: "");
  TextEditingController deptoController = TextEditingController(text: "");
  TextEditingController numeroserieController = TextEditingController(text: "");
  TextEditingController resguardadoController = TextEditingController(text: "");
  TextEditingController tanqueController = TextEditingController(text: "");
  TextEditingController tipoController = TextEditingController(text: "");
  TextEditingController trabajadorController = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    placaController.text=arguments['placa'];
    combustibleController.text=arguments['combustible'];
    deptoController.text=arguments['depto'];
    numeroserieController.text=arguments['numeroserie'];
    resguardadoController.text=arguments['resguardadopor'];
    tanqueController.text=arguments['tanque'].toString();
    tipoController.text=arguments['tipo'];
    trabajadorController.text=arguments['trabajador'];
    return Scaffold(
        appBar: AppBar(title: const Text("Editar vehiculo"),),
        body:Padding(padding: const EdgeInsets.all(10.0),
          child:  Column(
            children: [
              TextField(
                controller: placaController,
                decoration: const InputDecoration(
                  hintText:'Placa',
                ),
              ),
              TextField(
                controller: combustibleController,
                decoration: const InputDecoration(
                  hintText:'Combustible',
                ),
              ),
              TextField(
                controller: deptoController,
                decoration: const InputDecoration(
                  hintText:'depto',
                ),
              ),
              TextField(
                controller: numeroserieController,
                decoration: const InputDecoration(
                  hintText:'numeroserie',
                ),
              ),
              TextField(
                controller: resguardadoController,
                decoration:const InputDecoration(
                  hintText:'resguardadopor',
                ),
              ),
              TextField(
                controller: tanqueController,
                decoration: const InputDecoration(
                  hintText:'tanque',
                ),
              ),
              TextField(
                controller: tipoController,
                decoration: const InputDecoration(
                  hintText:'tipo',
                ),
              ),TextField(
                controller: trabajadorController,
                decoration: const InputDecoration(
                  hintText:'trabajador',
                ),
              ),
              //combustibleController.text, deptoController.text, numeroserieController.text, resguardadoController.text, int.parse(tanqueController.text), tipoController.text, trabajadorController.text
              SizedBox(height: 20),
              ElevatedButton(onPressed: ()async{
                await updateCoches(arguments['uid'],placaController.text,combustibleController.text, deptoController.text, numeroserieController.text, resguardadoController.text, int.parse(tanqueController.text), tipoController.text, trabajadorController.text).
                then((_){Navigator.pop(context); });
              }, child: const Text("Actualizar")),
              SizedBox(height: 20),
              ElevatedButton(onPressed: (){ alerta(arguments['uid'],arguments['placa']); }, child: const Text("Eliminar"),)
            ],
          ),
        )

    );
  }

  void alerta(String uid,String placa) {
    showDialog(context: context, builder: (builder){
      return AlertDialog(
        title: Text("ATENCION"),
        content: Text("¿Qué desea hacer con la placa ${placa}?"),
        actions: [
          TextButton(onPressed: (){
            deleteCoches(uid);
            Navigator.popUntil(context,ModalRoute.withName('/'));
          }, child: const Text("ELIMINAR")),
          TextButton(onPressed: () {
            Navigator.pop(context);
          }, child: const Text("CANCELAR"))
        ],
      );
    });
  }
}
