import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto1_18401194/services/firebase_service.dart';

class EditarBitacora extends StatefulWidget {
  const EditarBitacora({Key? key}) : super(key: key);

  @override
  State<EditarBitacora> createState() => _EditarBitacoraState();
}

class _EditarBitacoraState extends State<EditarBitacora> {

  TextEditingController verificoController=TextEditingController(text: "");
  TextEditingController fechaverificacionController=TextEditingController(text: "");
  TextEditingController fechaController=TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    fechaController.text=arguments['fecha']!=null ? arguments['fecha'].toDate().toString():'';
    verificoController.text= arguments['verifico'];
    fechaverificacionController.text = arguments['fechaverificacion']!=null ? arguments['fechaverificacion'].toDate().toString():'';
    return Scaffold(
      appBar: AppBar(title: const Text("Editar Bitacora"),),
      body: Padding(padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          TextField(
            controller: verificoController,
            decoration: const InputDecoration(
              hintText: 'verifico'
            ),
          ),
          TextField(
            controller: fechaverificacionController,
            decoration: const InputDecoration(
              hintText: 'fechaverificacion'
            ),

          ),
          SizedBox(height: 20,),
          ElevatedButton(onPressed: ()async{
            await updateBitacoras(arguments['uid'], verificoController.text, Timestamp.fromDate(DateTime.parse(fechaverificacionController.text)),
                Timestamp.fromDate(DateTime.parse(fechaController.text)),arguments['evento'],arguments['placa'],arguments['recursos']).
            then((_) {
              Navigator.pop(context);
            });
          }, child: const Text("Actualizar"))
        ],
      ),
      ),
    );
  }
}
