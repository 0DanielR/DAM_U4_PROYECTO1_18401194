import 'package:dam_u4_proyecto1_18401194/services/firebase_service.dart';
import 'package:flutter/material.dart';

class Insertarvehiculos extends StatefulWidget {
  const Insertarvehiculos({Key? key}) : super(key: key);

  @override
  State<Insertarvehiculos> createState() => _InsertarvehiculosState();
}

class _InsertarvehiculosState extends State<Insertarvehiculos> {
  TextEditingController placaController = TextEditingController(text: "");
  TextEditingController combustibleController = TextEditingController(text: "");
  TextEditingController deptoController = TextEditingController(text: "");
  TextEditingController numeroserieController = TextEditingController(text: "");
  TextEditingController resguardadoController = TextEditingController(text: "");
  TextEditingController tanqueController = TextEditingController(text: "");
  TextEditingController tipoController = TextEditingController(text: "");
  TextEditingController trabajadorController = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Agregar vehiculo"),),
      body:Padding(padding: const EdgeInsets.all(10.0),
      child:  Column(
        children: [
          TextField(
            controller: placaController,
            decoration: const InputDecoration(
              hintText:'Placa',
            ),
          ),
          TextField(
            controller: combustibleController,
            decoration: const InputDecoration(
              hintText:'Combustible',
            ),
          ),
          TextField(
            controller: deptoController,
            decoration: const InputDecoration(
              hintText:'depto',
            ),
          ),
          TextField(
            controller: numeroserieController,
            decoration: const InputDecoration(
              hintText:'numeroserie',
            ),
          ),
          TextField(
            controller: resguardadoController,
            decoration:const InputDecoration(
              hintText:'resguardadopor',
            ),
          ),
          TextField(
            controller: tanqueController,
            decoration: const InputDecoration(
              hintText:'tanque',
            ),
          ),
          TextField(
            controller: tipoController,
            decoration: const InputDecoration(
              hintText:'tipo',
            ),
          ),TextField(
            controller: trabajadorController,
            decoration: const InputDecoration(
              hintText:'trabajador',
            ),
          ),
          ElevatedButton(onPressed: ()async{
            await addCoches(placaController.text, combustibleController.text, deptoController.text, numeroserieController.text, resguardadoController.text, int.parse(tanqueController.text), tipoController.text, trabajadorController.text).then((_) {
              Navigator.pop(context);
            } );
          }, child: const Text("Guardar"))
        ],
      ),
      )

    );
  }
}
