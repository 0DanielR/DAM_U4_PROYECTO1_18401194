import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto1_18401194/services/firebase_service.dart';
import 'package:dam_u4_proyecto1_18401194/consultas.dart';
class ConsultaPlaca extends StatefulWidget {
  const ConsultaPlaca({Key? key}) : super(key: key);

  @override
  State<ConsultaPlaca> createState() => _ConsultaPlacaState();
}

class _ConsultaPlacaState extends State<ConsultaPlaca> {
  TextEditingController verDeptoController=TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    verDeptoController=arguments['placaver'];
    return Scaffold(
      appBar: AppBar(title: const Text("Bitacoras por placa"),backgroundColor: Colors.deepPurpleAccent,),
      body: FutureBuilder(
        future: getBitacoraPlaca(verDeptoController.text),
        builder: ((context,snapshot){
          if(snapshot.hasData){
            return ListView.builder(itemCount: snapshot.data?.length,itemBuilder: (context,index){
              return InkWell(onTap: (){},
                child: ListTile(
                  title: Text(snapshot.data?[index]['placa']),
                  subtitle: Text(snapshot.data?[index]['evento']),
                  trailing: Text(snapshot.data?[index]['recursos']),
                ),
              );
            },
            );
          }else{
            return const Center(child: Text("no se encuentra el departamento"),);
          }
        }
        ),
      ),

    );
  }
}