import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:dam_u4_proyecto1_18401194/services/firebase_service.dart';
import 'package:dam_u4_proyecto1_18401194/vehiculo.dart';
import 'package:dam_u4_proyecto1_18401194/bitacora.dart';
import 'package:dam_u4_proyecto1_18401194/consultas.dart';
class Programa extends StatefulWidget {
  const Programa({Key? key}) : super(key: key);

  @override
  State<Programa> createState() => _ProgramaState();
}

class _ProgramaState extends State<Programa> {
  int _pantalla =1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Coches"),),
      body: cargarPantallas(),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(child: Column(
              children: [
                CircleAvatar(child: Text("DAM", style: TextStyle(fontSize: 25,color: Colors.white),),
                radius: 45,
                ),
                SizedBox(height: 10,),
                Text("CONTROL DE VEHICULOS", style: TextStyle(fontSize: 20, color: Colors.white),)
              ],
            ),
              decoration: BoxDecoration(color: Colors.black54),
            ),
            _items("Ver vehiculos",Icons.accessible_forward_sharp,1),
            Divider(color: Colors.deepPurple,),
            _items("Ver Bitacora",Icons.receipt,2),
            Divider(color: Colors.deepPurple,),
            _items("Consultas", Icons.account_balance_wallet_outlined, 3),
            Divider(color: Colors.deepPurple,)
          ],
        ),
      ),
    );
  }

  Widget _items(String descripcion, IconData icono, int index){
    return InkWell(
      onTap: (){
        setState(() {
          _pantalla=index;
        });
        Navigator.pop(context);
      },
      child: Padding(
        padding: EdgeInsets.all(15),
        child: Row(
          children: [
            Expanded(child: Icon(icono)),
            Expanded(child: Text(descripcion),flex: 3,)
          ],
        ),
      ),
    );
  }

  Widget cargarPantallas(){
    switch(_pantalla){
      case 1:{
        return Vehiculo();
      }
      break;
      case 2:{
        return Bitacora();
      }
      break;
      case 3:{
        return Consultas();
      }
      break;
      default:
        return ListView();
    }
  }
}
