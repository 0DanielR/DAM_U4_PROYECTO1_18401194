import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto1_18401194/services/firebase_service.dart';

class Bitacora extends StatefulWidget {
  const Bitacora({Key? key}) : super(key: key);

  @override
  State<Bitacora> createState() => _BitacoraState();
}

class _BitacoraState extends State<Bitacora> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Bitacora"),backgroundColor: Colors.blueGrey,),
      body: FutureBuilder(
        future: getBitacora(),
        builder: ((context,snapshot){
          if(snapshot.hasData){
            return ListView.builder(itemCount: snapshot.data?.length,itemBuilder: (context,index){
              return InkWell(onTap: ()async{
                await Navigator.pushNamed(context, '/editB',
                arguments:{
                  "verifico":snapshot.data?[index]['verifico'],
                  "fechaverificacion":snapshot.data?[index]['fechaverificacion'],
                  "fecha":snapshot.data?[index]['fecha'],
                  "placa":snapshot.data?[index]['placa'],
                  "evento":snapshot.data?[index]['evento'],
                  "recursos":snapshot.data?[index]['recursos'],
                  "uid":snapshot.data?[index]['uid']
                } );setState(() {

                });
              },
                child: ListTile(
                  title: Text(snapshot.data?[index]['placa']),
                  subtitle: Text(snapshot.data?[index]['verifico']),
                  trailing: Text(snapshot.data?[index]['evento']),
                ),
              );
            },

            );
          }
          else{
            return const Center(child: CircularProgressIndicator(),);
          }
        }),
      ),
      floatingActionButton: FloatingActionButton(onPressed: ()async{
        await Navigator.pushNamed(context, "/addB");
        setState(() {

        });
      },
      child: Icon(Icons.add),),
    );
  }
}
