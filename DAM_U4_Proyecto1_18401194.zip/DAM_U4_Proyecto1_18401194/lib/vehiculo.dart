import 'package:dam_u4_proyecto1_18401194/editarCoche.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:dam_u4_proyecto1_18401194/services/firebase_service.dart';

import 'insertarvehiculos.dart';

class Vehiculo extends StatefulWidget {
  const Vehiculo({Key? key}) : super(key: key);

  @override
  State<Vehiculo> createState() => _VehiculoState();
}

class _VehiculoState extends State<Vehiculo> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Vehiculos"),backgroundColor: Colors.blueGrey,),
      body: FutureBuilder(
        future: getCoches(),
        builder: ((context,snapshot){
          if(snapshot.hasData){
            return ListView.builder(itemCount: snapshot.data?.length,itemBuilder: (context, index){
              return InkWell(onTap: ()async{
                await Navigator.pushNamed(context, "/editV",arguments:{
                  "placa":snapshot.data?[index]['placa'],
                  "combustible":snapshot.data?[index]['combustible'],
                  "depto":snapshot.data?[index]['depto'],
                  "numeroserie":snapshot.data?[index]['numeroserie'],
                  "resguardadopor":snapshot.data?[index]['resguardadopor'],
                  "tanque":snapshot.data?[index]['tanque'],
                  "tipo":snapshot.data?[index]['tipo'],
                  "trabajador":snapshot.data?[index]['trabajador'],
                  "uid":snapshot.data?[index]['uid']
                }
                );setState(() {

                });
              },
                child: ListTile(
                  title: Text(snapshot.data?[index]['placa']),
                  subtitle: Text(snapshot.data?[index]['trabajador']),
                  trailing: Text(snapshot.data?[index]['tipo']),
                ),
              );
            },);
          }
          else{
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

        }),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: ()async{
          await Navigator.pushNamed(context, "/addV");
          setState(() {

          });
        },
        child: Icon(Icons.add),
      ),
    );
  }


}
// TODO Implement this library.